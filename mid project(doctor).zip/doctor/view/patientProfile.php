<html>
<head></head>
<title>Patients Profile</title>
<body>

<center>
<form method="post" action="">
	<table cellspacing="0" width="40%"  border="1">
		<tr>
			<td colspan="4" align="center"><h2>Patients Details</h2></td>
		</tr>
		<tr >
			<th>Patients Names</th>
			<th>Details</th>
			<th>History</th>
			<th>Date</th>
		</tr> 
		<tr >
			<th>Sumit</th>
			<th>
				height: 5'10" <br>
				weight: 86 KG <br>
				age:24
			</th>
			<th >fever</th>
			<th >11-02-20</th>
		</tr>
	</table>
</form>
</center>
</body>
</html>