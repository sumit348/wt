<html>
<head></head>
<title>Schedule</title>
<body>

<center>
<form method="post" action="">
	<table cellspacing="0" width="40%"  border="1">
		<tr>
			<td colspan="3" align="center"><h2>Appointments</h2></td>
		</tr>
		<tr >
			<th >Appointment Date</th>
			<th >Patients Name</th>
			<th >Time</th>
		</tr> 
		<tr >
			<th>12-06-20</th>
			<th>Dipto Mondol</th>
			<th >1.AM</th>
		</tr>
		<tr >
			<th>12-06-20</th>
			<th>Tania Karim</th>
			<th >1.30AM</th>
		</tr> 
		<tr >
			<th>13-06-20</th>
			<th>Nishat Tasnim</th>
			<th >2.30.AM</th>
		</tr> 
	</table>
</form>
</center>
</body>
</html>