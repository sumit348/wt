
<!DOCTYPE HTML>
<html>
	<head>
		
		<title>Doctor Profile</title>
	</head>
	<body>
		<div>
			<table border="1">	
					</tr>
						<td colspan ="2" width ="100%" height="50px" align="center"><h1>Welcome to Doctor Profile</h1></td>
					</tr>
					</tr>
						<td>
							<ul>
								<li><a href="editProfile.php"><h3>Edit Profile</h3></a></li>
								<li><a href="changePassword.php"><h3>Change Password</h3></a></li>
								<li><a href="../control/logout.php"><h3>Logout</h3></a></li>
							</ul>
						</td>
						<td width ="1200px" height ="700px">
							<fieldset>
								<legend>Profile</legend>	
									<table align="center">
										
										<tr>
											<td></td>
											<td></td>
											<td></td>
											<td align="right"><img width="200px" src="u.jpg" alt="Profile picture" /></td>
											<td><input type="file" value="choose file"></td>
										</tr>
										<tr>
		
											<td>User Id:</td>
											<td><?php
												echo "17-387483-2"		
											     ?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Name:</td>
											<td><?php
											echo "Mehedi Hasan";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Email:</td>
											<td><?php echo "mehedi@gmail.com";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Gender:</td>
											<td><?php echo "Male"  ?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Address:</td>
											<td><?php echo "Nikunja-2";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Joining Date:</td>
											<td><?php echo "2020-02-14";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Blood Group:</td>
											<td><?php echo "0+";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Phone:</td>
											<td><?php echo "01834833884";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Date Of Birth:</td>
											<td><?php echo "1997-06-11";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td></td>
											<td></td>
											<td></td>
										</tr>											
									</table>	
							</fieldset>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center"><h4>Copyright from w3school.com<h4></td>
					</tr>
			</table>
			</div>
					
			
	</body>
</html>