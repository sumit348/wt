<?php
if(isset($_REQUEST['submit'])){

   
   echo  $_REQUEST["txt"];
   
   

}
?>