<html>
<head></head>
<title> Review</title>
<body>

<center>
<form method="post" action="reviewSubmit.php">

<table>
	<tr>
		<td>Review:</td>
		<td><textarea rows="10" cols="30" name="txt"></textarea></td>
		<td><input type="submit" value ="Send" name="submit"></td>
	</tr>
</table>
	
</form>
</center>
</body>
</html>