<html>
<head></head>
<title>Salary History</title>
<body>

<center>
<form method="post" action="">
	<table cellspacing="0" width="40%"  border="1">
		<tr>
			<td colspan="3" align="center"><h2>Salary History</h2></td>
		</tr>
		<tr >
			<th>Year</th>
			<th>Month</th>
			<th>Salary</th>
		</tr> 
		<tr >
			<th>2020</th>
			<th>June</th>
			<th >50000</th>
		</tr>
		<tr >
			<th>2020</th>
			<th>July</th>
			<th >55000</th>
		</tr>
		<tr >
			<th>2020</th>
			<th>Auguest</th>
			<th >55000</th>
		</tr>
		<tr >
			<th>2020</th>
			<th>September</th>
			<th >60000</th>
		</tr>
		<tr>
		<td height="50px">Search Salary :
			<input type="datetime-local">
			<input type="submit" value="Submit" name="submit">
		</td>
		
	</tr>
	</table>
</form>
</center>
</body>
</html>