<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<form action="schedulePage.php">
<fieldset>
  <table>

	<tr>
		<td width ="1200px" align ="center" colspan="2"><h2>Welcome Doctor</h2></td>
	</tr>
	<tr>
	
		<td height="50px" colspan="2">
			<a href="profile.php"><input type="button" value="Profile"></a>
		</td>
	</tr>
	<tr>
		<td height="50px">Search Appointment:
			<input type="datetime-local">
			<input type="submit" value="Submit" name="submit">
		</td>
		
	</tr>
	<tr>
	
		<td colspan="2" height="50px">
			<a href="patientProfile.php"><input type="button" value="Patient Profile "></a>
		</td>
	</tr>
	<tr>
	
		<td colspan="2" height="50px">
			<a href="requestAdmin.php"><input type="button" value="Request Admin"></a>
		</td>
	</tr>
	<tr>
		<td colspan="2" height="50px">
			<a href="review.php"><input type="button" value="Review"></a>
		</td>
	</tr>
	<tr>
		<td colspan="2" height="50px">
			<a href="salaryhistory.php" ><input type="button" value="salary history"></a>
		</td>
	</tr>
	<tr>
		<td colspan="2" height="50px">
			<a href="../control/logout.php"><input type="button" value="Logout"></a>
		</td>
	</tr>
	<tr>
		<td height="200px"> 
		</td>
	</tr>
	
	
  </table>
 </fieldset> 

</form>
</body>
</html>