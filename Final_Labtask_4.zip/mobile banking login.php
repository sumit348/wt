<html>
<head></head>
<title>Login</title>
<body>

<center>
<form>
	<table border="0" cellspacing="0" cellpadding="0" width="30%" >
		<tr >
			<td >
				<fieldset >
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input type="text" name="id"><br/>                               
					Password<br/>
					<input type="password" name="password">
					<br /><hr/>
					<input type="submit" value="Login" name="submit">
					
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>
</body>
</html>